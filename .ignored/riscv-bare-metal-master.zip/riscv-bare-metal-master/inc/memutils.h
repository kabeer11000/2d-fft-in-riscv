#ifndef MEMUTILS_H
#define MEMUTILS_H
#include "stdint.h"
void *c_memset(void *dst, int c, uint32_t n);
#endif
